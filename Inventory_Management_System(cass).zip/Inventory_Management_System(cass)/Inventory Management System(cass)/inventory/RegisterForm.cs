using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace inventory
{
    public partial class RegisterForm : Form
    {
        private readonly Form signInForm;

        public RegisterForm()
        {
            InitializeComponent();
        }

        public RegisterForm(Form signIn)
        {
            InitializeComponent();
            signInForm = signIn;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirm = txtConfirm.Text;

            if (fullName == "" || username == "" || password == "" || confirm == "")
            {
                MessageBox.Show("Please fill in all fields.", "Register", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (password.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters.", "Register", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (password != confirm)
            {
                MessageBox.Show("Passwords do not match.", "Register", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (OleDbConnection con = Database.GetConnection())
                {
                    con.Open();

                    // 1. Is the username already taken?
                    using (OleDbCommand check = new OleDbCommand("SELECT COUNT(*) FROM Users WHERE Username = ?", con))
                    {
                        check.Parameters.Add("?", OleDbType.VarWChar).Value = username;
                        if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("That username is already taken.", "Register", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // 2. The very first account becomes the Admin, everyone else is Staff
                    string role = "Staff";
                    using (OleDbCommand count = new OleDbCommand("SELECT COUNT(*) FROM Users", con))
                    {
                        if (Convert.ToInt32(count.ExecuteScalar()) == 0) role = "Admin";
                    }

                    // 3. Insert the new user (password stored as a SHA-256 hash, never plain text)
                    using (OleDbCommand insert = new OleDbCommand(
                        "INSERT INTO Users (Username, PasswordHash, FullName, UserRole, IsActive) VALUES (?, ?, ?, ?, ?)", con))
                    {
                        insert.Parameters.Add("?", OleDbType.VarWChar).Value = username;
                        insert.Parameters.Add("?", OleDbType.VarWChar).Value = Database.HashPassword(password);
                        insert.Parameters.Add("?", OleDbType.VarWChar).Value = fullName;
                        insert.Parameters.Add("?", OleDbType.VarWChar).Value = role;
                        insert.Parameters.Add("?", OleDbType.Boolean).Value = true;
                        insert.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Account created! You can now sign in.", "Register", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();   // FormClosed brings the Sign In form back
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Register", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        private void RegisterForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (signInForm != null) signInForm.Show();
        }
    }
}
