using System;
using System.Windows.Forms;

namespace inventory
{
    public partial class DashboardForm : Form
    {
        private readonly int currentUserId;
        private readonly Form signInForm;
        private bool loggedOut = false;

        // Needed so the Visual Studio designer can open this form
        public DashboardForm()
        {
            InitializeComponent();
        }

        public DashboardForm(int userId, string fullName, string role, Form signIn)
        {
            InitializeComponent();
            currentUserId = userId;
            signInForm = signIn;
        }

        // Logout: back to the Sign In page
        private void btnLogout_Click(object sender, EventArgs e)
        {
            Database.LogActivity(currentUserId, "Signed out");
            loggedOut = true;
            if (signInForm != null) signInForm.Show();
            this.Close();
        }

        private void DashboardForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Closing with the X button ends the whole application
            if (!loggedOut) Application.Exit();
        }
    }
}
