using System;
using System.Data.OleDb;
using System.Windows.Forms;

namespace inventory
{
    public partial class SignInForm : Form
    {
        public SignInForm()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;

            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter your username and password.", "Sign In",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int userId;
            string fullName;
            string role;

            try
            {
                using (OleDbConnection con = Database.GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(
                    "SELECT UserID, FullName, UserRole, IsActive FROM Users WHERE Username = ? AND PasswordHash = ?", con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = username;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = Database.HashPassword(password);
                    con.Open();

                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            MessageBox.Show("Invalid username or password.", "Sign In",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        if (!Convert.ToBoolean(reader["IsActive"]))
                        {
                            MessageBox.Show("This account is disabled.", "Sign In",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        userId = Convert.ToInt32(reader["UserID"]);
                        fullName = reader["FullName"].ToString();
                        role = reader["UserRole"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Sign In", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Welcome, " + fullName + "!", "Sign In",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            Database.LogActivity(userId, "Signed in");

            txtUsername.Clear();
            txtPassword.Clear();

            // Open the dashboard and hide this form (Log Out brings it back)
            DashboardForm dashboard = new DashboardForm(userId, fullName, role, this);
            dashboard.Show();
            this.Hide();
        }

        private void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterForm register = new RegisterForm(this);
            register.Show();
            this.Hide();
        }
    }
}
