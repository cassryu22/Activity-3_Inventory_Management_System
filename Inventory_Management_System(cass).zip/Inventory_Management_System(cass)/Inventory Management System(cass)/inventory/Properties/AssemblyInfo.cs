using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("inventory")]
[assembly: AssemblyDescription("Inventory Management System - Sign In and Register")]
[assembly: AssemblyProduct("inventory")]
[assembly: ComVisible(false)]
[assembly: Guid("8f3b2c14-6a5d-4e7b-9c21-3d5e7a1b4c62")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
