INVENTORY MANAGEMENT SYSTEM - Sign In + Register (black and white design)

1. Extract this zip.
2. Double-click inventory.sln (opens in Visual Studio).
3. Install the Microsoft Access Database Engine (ACE OLEDB 12.0) - 32/64-bit to match your Office.
4. Press F5 to run.

Database (follows the video):
 - sampledb.accdb is in the project folder (inventory\sampledb.accdb), next to inventory.csproj.
 - Database.cs holds the path (DBpATH) and the connection string (Microsoft.ACE.OLEDB.12.0).
 - Tables: Users, Products, StockTransactions, ActivityLogs (Users: UserID, Username, PasswordHash, FullName, UserRole, IsActive).
 - Close the database in Access before running the app.
Sample account: Lara / Lara123
